const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];

const loginScreen = $("#loginScreen");
const app = $("#app");
const DEMO_EMAIL = "admin@aerova.city";
const DEMO_PASSWORD = "aerova123";
let toastTimer;
let mapScale = 1;
let currentUser = "Admin";

function toast(message) {
  const element = $("#toast");
  if (!element) return;
  element.textContent = message;
  element.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => element.classList.remove("show"), 2800);
}

function enterApp() {
  loginScreen.classList.add("hidden");
  app.classList.remove("hidden");
  const error = $("#loginError");
  if (error) error.textContent = "";
  toast(`Welcome to AEROVA City Control Center, ${currentUser}`);
  initMaps();
  drawCharts();
  applySavedSettings();
}

$("#loginForm").addEventListener("submit", event => {
  event.preventDefault();
  const email = $("#loginEmail").value.trim().toLowerCase();
  const password = $("#loginPassword").value;
  const error = $("#loginError");
  if (email !== DEMO_EMAIL || password !== DEMO_PASSWORD) {
    error.textContent = "Login details are incorrect. Use the demo account shown below.";
    $("#loginPassword").setAttribute("aria-invalid", "true");
    return;
  }
  $("#loginPassword").removeAttribute("aria-invalid");
  currentUser = email === DEMO_EMAIL ? "Admin" : "User";
  try { sessionStorage.setItem("aerovaSignedIn", "true"); } catch (_) {}
  enterApp();
});

function logout() {
  app.classList.add("hidden");
  loginScreen.classList.remove("hidden");
  closeAllWindows();
  try { sessionStorage.removeItem("aerovaSignedIn"); } catch (_) {}
  $("#loginPassword").value = "";
  toast("You have logged out of AEROVA");
}
$("#logoutBtn").onclick = logout;
$("#profileLogout").onclick = logout;

function showView(name) {
  $$(".view").forEach(view => view.classList.remove("active-view"));
  const target = $("#view-" + name);
  if (target) target.classList.add("active-view");
  $$(".nav-item[data-view]").forEach(button => button.classList.toggle("active", button.dataset.view === name));
  if (name === "energy" || name === "analytics") drawCharts();
  if (name === "map") initMaps();
  if (window.innerWidth <= 900) document.body.classList.remove("mobile-nav-open");
}
$$(".nav-item[data-view]").forEach(button => button.addEventListener("click", () => showView(button.dataset.view)));
$$("[data-view-link]").forEach(button => button.addEventListener("click", () => {
  showView(button.dataset.viewLink);
  closeAllWindows();
}));
$("#menuBtn").onclick = () => {
  if (window.innerWidth <= 900) document.body.classList.toggle("mobile-nav-open");
  else document.body.classList.toggle("compact-sidebar");
};
$("#compactToggle").onchange = event => {
  document.body.classList.toggle("compact-sidebar", event.target.checked);
  saveSetting("compactSidebar", event.target.checked);
};
$("#darkToggle").onchange = event => {
  document.body.classList.toggle("light-mode", !event.target.checked);
  saveSetting("darkMode", event.target.checked);
  toast(event.target.checked ? "Dark interface enabled" : "Light interface enabled");
};

function clock() {
  const el = $("#clock");
  if (el) el.textContent = new Date().toLocaleTimeString([], { hour12: false });
}
setInterval(clock, 1000);
clock();

let zIndex = 120;
function openWindow(id) {
  const win = $("#" + id);
  if (!win) return;
  win.classList.add("show");
  win.style.zIndex = ++zIndex;
}
function closeAllWindows() { $$(".floating-window").forEach(win => win.classList.remove("show")); }
$$("[data-open]").forEach(button => button.addEventListener("click", () => openWindow(button.dataset.open)));
$$(".close-window").forEach(button => button.addEventListener("click", () => button.closest(".floating-window").classList.remove("show")));
$("#notificationBtn").onclick = () => openWindow("notificationWindow");
$("#profileBtn").onclick = () => openWindow("profileWindow");

function makeDraggable(win) {
  const head = win.querySelector(".window-head");
  if (!head) return;
  let dragging = false, offsetX = 0, offsetY = 0;
  const start = (clientX, clientY) => {
    dragging = true;
    win.style.zIndex = ++zIndex;
    const rect = win.getBoundingClientRect();
    offsetX = clientX - rect.left;
    offsetY = clientY - rect.top;
    document.body.style.userSelect = "none";
  };
  const move = (clientX, clientY) => {
    if (!dragging) return;
    win.style.left = Math.max(8, Math.min(window.innerWidth - win.offsetWidth - 8, clientX - offsetX)) + "px";
    win.style.top = Math.max(70, Math.min(window.innerHeight - win.offsetHeight - 8, clientY - offsetY)) + "px";
  };
  const stop = () => { dragging = false; document.body.style.userSelect = ""; };
  head.addEventListener("mousedown", event => start(event.clientX, event.clientY));
  window.addEventListener("mousemove", event => move(event.clientX, event.clientY));
  window.addEventListener("mouseup", stop);
  head.addEventListener("touchstart", event => {
    const touch = event.touches[0];
    start(touch.clientX, touch.clientY);
  }, { passive: true });
  window.addEventListener("touchmove", event => {
    if (dragging && event.touches[0]) move(event.touches[0].clientX, event.touches[0].clientY);
  }, { passive: true });
  window.addEventListener("touchend", stop);
}
$$(".floating-window").forEach(makeDraggable);

// The map is a clickable simulated digital twin. Its values are demo data, not live city telemetry.
function initMaps() {
  const maps = [$("#homeMap"), $("#mainMap")].filter(Boolean);
  maps.forEach(map => {
    if (map.dataset.ready) return;
    const markers = [
      ["🚦", "32", "36", "Central Avenue", "Traffic utilization: 68%"],
      ["⚡", "61", "24", "Solar Plant", "Generation: 286 MW"],
      ["💧", "76", "66", "Reservoir", "Reserve level: 68%"],
      ["🚌", "45", "72", "Route 19", "Passenger load: 88"],
      ["🚨", "22", "61", "West Park", "Safety status: normal"],
      ["🚦", "70", "48", "Airport Corridor", "Traffic utilization: 59%"],
      ["🚌", "28", "25", "Central Station", "Passenger load: 72"]
    ];
    markers.forEach(([icon, x, y, title, detail]) => {
      const marker = document.createElement("button");
      marker.className = "marker";
      marker.type = "button";
      marker.textContent = icon;
      marker.style.left = x + "%";
      marker.style.top = y + "%";
      marker.title = `${title} — ${detail}`;
      marker.setAttribute("aria-label", `${title}: ${detail}`);
      marker.addEventListener("click", () => toast(`${title}: ${detail}`));
      map.appendChild(marker);
    });
    map.dataset.ready = "1";
  });
}
$("#zoomIn").onclick = () => setMapZoom(Math.min(1.6, mapScale + 0.1));
$("#zoomOut").onclick = () => setMapZoom(Math.max(0.7, mapScale - 0.1));
$("#resetMap").onclick = () => setMapZoom(1);
function setMapZoom(scale) {
  mapScale = scale;
  const map = $("#mainMap");
  map.style.transform = `scale(${mapScale})`;
  toast(`Map zoom: ${Math.round(mapScale * 100)}%`);
}

$("#simulateTraffic").onclick = () => {
  const value = Math.floor(65 + Math.random() * 25);
  $("#trafficStat").textContent = value + "%";
  $("#trafficForecast").textContent = value > 82 ? "High" : value > 72 ? "Moderate" : "Low";
  $("#congested").textContent = Math.floor(6 + Math.random() * 5);
  $("#windowTraffic").textContent = value + "%";
  toast("Demo traffic prediction completed");
};
$("#windowTrafficBtn").onclick = () => {
  const value = Math.floor(55 + Math.random() * 40);
  $("#windowTraffic").textContent = value + "%";
  $("#trafficStat").textContent = value + "%";
  toast("Simulated traffic flow updated");
};
$("#optimizeEnergy").onclick = () => toast("Demo grid optimization completed — estimated peak demand reduced by 4.8%");
$("#scanWater").onclick = () => {
  $("#leaks").textContent = Math.floor(Math.random() * 3) + 1;
  toast("Simulated water network scan completed");
};
$("#optimizeWaste").onclick = () => {
  $("#routes").textContent = String(Number($("#routes").textContent) + 2);
  toast("Demo collection routes optimized");
};
$("#refreshFleet").onclick = () => toast("Demo fleet telemetry refreshed");
$("#testAlert").onclick = () => toast("Test alert simulated. No real emergency services were contacted.");

$$(".fleet-row button").forEach(button => button.addEventListener("click", () => {
  const row = button.closest(".fleet-row");
  toast(`${button.textContent}: ${row.querySelector("span").textContent} — ${row.querySelector("b").textContent}`);
}));

$("#exportData").onclick = () => {
  const rows = [
    ["AEROVA CITY REPORT", "Value"],
    ["Traffic Flow", $("#trafficStat").textContent],
    ["Energy Health", "84%"],
    ["Water Reserve", "68%"],
    ["Air Quality", "AQI 42"],
    ["Safety Score", "96%"],
    ["Generated At", new Date().toLocaleString()],
    ["Data Note", "Prototype simulation values; not live city data"]
  ];
  const csv = rows.map(row => row.map(value => `"${String(value).replaceAll('"', '""')}"`).join(",")).join("\r\n");
  const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = "aerova-city-report.csv";
  document.body.appendChild(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
  toast("City report exported as CSV");
};

function aiReply(question) {
  const q = question.toLowerCase();
  if (q.includes("traffic") || q.includes("road") || q.includes("congestion"))
    return "Demo traffic data shows Central Avenue at about 68% utilization and Airport Corridor at 59%. Use Traffic Management → Run AI Prediction to simulate a new forecast.";
  if (q.includes("energy") || q.includes("power") || q.includes("solar"))
    return "Demo energy demand is 842 MW. Solar generation is 286 MW, covering approximately 34% of demand. Use Energy Grid → Optimize Grid to run the interface simulation.";
  if (q.includes("water") || q.includes("leak") || q.includes("reservoir"))
    return "Demo water reserves are at 68%. Two possible leak patterns are listed for review. Use Water Network → Scan for Leaks to simulate a scan.";
  if (q.includes("bus") || q.includes("transport") || q.includes("fleet"))
    return "The demo dashboard shows 186 active buses, 94% on-time performance and a 62% electric-vehicle fleet share.";
  if (q.includes("safety") || q.includes("incident") || q.includes("emergency"))
    return "The demo safety score is 96%, with three sample incidents listed. The test-alert button only displays a simulation message; it does not contact emergency services.";
  if (q.includes("waste") || q.includes("recycl"))
    return "The demo includes 842 smart bins, a 61% average fill level and a 74% recycling rate. Use Smart Waste → Optimize Routes to simulate route optimization.";
  if (q.includes("help") || q.includes("hello") || q.includes("hi"))
    return "Hello! I can explain the demo's traffic, energy, water, waste, transport, safety and analytics panels. Try asking: 'What is the energy status?'";
  return "I can answer using AEROVA's sample dashboard values for traffic, energy, water, waste, transport and safety. This assistant uses local rule-based replies, not a connected AI service.";
}
function addChat(message, type) {
  const box = $("#chatMessages");
  const bubble = document.createElement("div");
  bubble.className = "chat " + type;
  bubble.textContent = message;
  box.appendChild(bubble);
  box.scrollTop = box.scrollHeight;
}
$("#sendAi").onclick = () => {
  const input = $("#aiInput");
  const question = input.value.trim();
  if (!question) return;
  addChat(question, "user");
  input.value = "";
  setTimeout(() => addChat(aiReply(question), "ai"), 220);
};
$("#aiInput").addEventListener("keydown", event => {
  if (event.key === "Enter") $("#sendAi").click();
});
$$("[data-ai]").forEach(button => button.addEventListener("click", () => {
  showView("ai");
  addChat(button.dataset.ai, "ai");
}));

function drawLine(canvasId, values) {
  const canvas = $("#" + canvasId);
  if (!canvas) return;
  const ctx = canvas.getContext("2d");
  const width = canvas.clientWidth || 700;
  const height = Number(canvas.getAttribute("height")) || 220;
  const ratio = window.devicePixelRatio || 1;
  canvas.width = width * ratio;
  canvas.height = height * ratio;
  ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
  ctx.clearRect(0, 0, width, height);
  ctx.strokeStyle = getComputedStyle(document.body).getPropertyValue("--grid-line").trim() || "#20384f";
  ctx.lineWidth = 1;
  for (let i = 1; i < 5; i++) {
    const y = i * height / 5;
    ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(width, y); ctx.stroke();
  }
  ctx.strokeStyle = "#55d8ff"; ctx.lineWidth = 3; ctx.beginPath();
  values.forEach((value, index) => {
    const x = index * (width / (values.length - 1));
    const y = height - (value / 100) * height * 0.82 - 12;
    index ? ctx.lineTo(x, y) : ctx.moveTo(x, y);
  });
  ctx.stroke();
  ctx.fillStyle = "#55d8ff";
  values.forEach((value, index) => {
    const x = index * (width / (values.length - 1));
    const y = height - (value / 100) * height * 0.82 - 12;
    ctx.beginPath(); ctx.arc(x, y, 3, 0, Math.PI * 2); ctx.fill();
  });
}
function drawCharts() {
  drawLine("energyChart", [28,24,22,20,25,38,55,72,81,76,70,68,66,64,62,65,70,78,88,82,67,53,42,34]);
  drawLine("analyticsChart", [38,45,42,58,61,57,68,72,70,76,81,88]);
}
window.addEventListener("resize", () => {
  drawCharts();
  if (window.innerWidth > 900) document.body.classList.remove("mobile-nav-open");
});

// Store user interface preferences locally in this browser.
function saveSetting(key, value) {
  try {
    const settings = JSON.parse(localStorage.getItem("aerovaSettings") || "{}");
    settings[key] = value;
    localStorage.setItem("aerovaSettings", JSON.stringify(settings));
  } catch (_) {}
}
function applySavedSettings() {
  let settings = {};
  try { settings = JSON.parse(localStorage.getItem("aerovaSettings") || "{}"); } catch (_) {}
  if (typeof settings.darkMode === "boolean") {
    $("#darkToggle").checked = settings.darkMode;
    document.body.classList.toggle("light-mode", !settings.darkMode);
  }
  if (typeof settings.compactSidebar === "boolean") {
    $("#compactToggle").checked = settings.compactSidebar;
    document.body.classList.toggle("compact-sidebar", settings.compactSidebar);
  }
  const toggles = $$(".settings-panel input[type='checkbox']");
  toggles.forEach(input => {
    if (input.id === "darkToggle" || input.id === "compactToggle") return;
    const key = input.parentElement.querySelector("b")?.textContent || "setting";
    const stored = settings[key];
    if (typeof stored === "boolean") input.checked = stored;
    input.onchange = () => saveSetting(key, input.checked);
  });
}

// This remains a front-end demo. Session state lasts only for the current browser tab.
try {
  if (sessionStorage.getItem("aerovaSignedIn") === "true") enterApp();
} catch (_) {}
