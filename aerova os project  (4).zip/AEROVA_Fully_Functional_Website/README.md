# AEROVA — Intelligent Smart City Platform

A polished, responsive smart-city control-center prototype based on your original HTML, CSS and JavaScript. It keeps the AEROVA dashboard design and improves the main interactions, feedback and mobile usability.

## Features
- Demo login with validation and clear error messages
- City Home dashboard and sidebar navigation
- Interactive simulated city map with clickable asset markers and zoom controls
- Traffic prediction, energy optimization, water scan and waste-route simulations
- Transport fleet actions and safety test-alert feedback
- Rule-based AEROVA assistant in the AI Center
- Analytics and energy charts drawn without external libraries
- CSV city report export
- Draggable floating windows (mouse and touch)
- Notifications, profile window, logout and toast messages
- Dark/light and compact-sidebar preferences saved in the browser
- Responsive layout for desktop and mobile screens

## Run locally
1. Extract the ZIP.
2. Open the `AEROVA_Fully_Functional_Website` folder in Visual Studio Code.
3. Open `index.html` in a browser, or install the **Live Server** extension and choose **Open with Live Server**.
4. Sign in with the demo account below.

**Email:** `admin@aerova.city`  
**Password:** `aerova123`

## Important limitations
This is a front-end prototype. Dashboard metrics, map markers, charts, prediction outputs and AI replies are sample/simulated data. Login is demo-only and is not secure production authentication. The safety test does not contact emergency services. There is no server, database, live GIS, real IoT feed or real AI API connected.

For production use, add a backend API, secure server-side authentication, role permissions, a database, validated live-data sources, a real map provider and appropriate security/privacy controls. Never use the demo login for real accounts.
